const formatDate = date => {
  const year = new Date().getFullYear()
  const month =new Date().getMonth() + 1
  const day = new Date().getDate()
  

  return [year, month, day].map(formatNumber).join('-') 
}

const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}

module.exports = {
  formatDate: formatDate
}