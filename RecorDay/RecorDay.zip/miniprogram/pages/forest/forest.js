const app = getApp()
const util = require('../../utils/forestime.js')

Page({
  data: {
    clockShow:false,
    clockHeight: 0,
    time:'5',
    mTime:300000,
    timeStr:'05:00',
    rate:'',
    timer:null,
    cateArr:[
      {
        text:'工作'
      },
      {
        text:"学习",
      },
      {
        text:'运动'
      }
    ],
    cateActive:'0',
    okShow:false,
    pauseShow:true,
    startime:"",//开始时间 年月日时分秒
    startime_0:"",//点击开始时的毫秒数（1970/01/01至今毫秒数）
    keeptime:"",//坚持时间（毫秒）
    continueCancleShow:false
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../forlog/forlogs'
    })
  },
  onLoad: function () {
    // 750rpx 
    var res = wx.getSystemInfoSync();//获取设备系统信息
    console.log(res);
    var rate = 750 / res.windowWidth;

              //  ? / res.windowHeight;
    this.setData({
      rate: rate,
      clockHeight: 0.55*rate* res.windowHeight
    })
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  slideChange: function (e) {
    this.setData({
      time:e.detail.value
    })
  },
  clickCate:function (e) {
    this.setData({
      cateActive:e.currentTarget.dataset.index
    })
  },
  start: function () {
    var time_0= util.formatTime(new Date())
    var time_1=new Date().getTime()
    this.setData({
      startime:time_0,
      startime_0:time_1,
      clockShow:true,
      mTime:this.data.time*60*1000,
      timeStr:parseInt(this.data.time) >= 10 ? this.data.time+':00' : '0'+this.data.time+':00'
    })
    console.log(this.data.startime)
    this.drawBg();
    this.drawActive();
  },
  drawBg:function () {
    var lineWidth = 6 / this.data.rate; // px
    var ctx =wx.createCanvasContext('progress_bg');
    ctx.setLineWidth(lineWidth);
    ctx.setStrokeStyle('#000000');
    ctx.setLineCap('round');//断点形状
    ctx.beginPath();
    ctx.arc(400/this.data.rate/2,380/this.data.rate/2,400/this.data.rate/2- 2* lineWidth,0,2*Math.PI,false);//圆心坐标，半径
    ctx.stroke();
    ctx.draw();
  },
  drawActive: function () {
    var _this = this;
    var timer = setInterval(function (){
       var angle = 1.5 + 2*(_this.data.time*60*1000 - _this.data.mTime)/(_this.data.time*60*1000);
      var currentTime = _this.data.mTime - 100
      _this.setData({
          mTime: currentTime
      });
      if(angle < 3.5) {
        if(currentTime % 1000 == 0) {
          var timeStr1 = currentTime / 1000; // s
          var timeStr2 = parseInt(timeStr1 / 60) // m
          var timeStr3 = (timeStr1 - timeStr2 * 60) >= 10 ? (timeStr1 - timeStr2 * 60) : '0' + (timeStr1 - timeStr2 * 60);
          var timeStr2 = timeStr2 >= 10 ? timeStr2:'0'+timeStr2;
          _this.setData({
            timeStr:timeStr2+':'+timeStr3
          })
        }
        var lineWidth = 6 / _this.data.rate; // px
        var ctx = wx.createCanvasContext('progress_active');
        ctx.setLineWidth(lineWidth);
        ctx.setStrokeStyle('#ffffff');
        ctx.setLineCap('round');
        ctx.beginPath();
        ctx.arc(400 / _this.data.rate / 2, 380 / _this.data.rate / 2, 400 / _this.data.rate / 2 - 2 * lineWidth, 1.5 * Math.PI, angle * Math.PI, false);
        ctx.stroke();
        ctx.draw();
      } else {
        var logs = wx.getStorageSync('logs') || [];//获取记录
        logs.unshift({//在logs数组中压入元素
          date: util.formatTime(new Date),//日期
          cate: _this.data.cateActive,//标签类型
          time: _this.data.time//时间
        });
        wx.setStorageSync('logs', logs);//存入key:logs中
        _this.setData({
          timeStr:'00:00',
          okShow:true,
          pauseShow: false,
          continueCancleShow: false        
        })
        clearInterval(timer);
      }
    },100);
    _this.setData({
      timer:timer
    })
  },
  pause: function () {
    clearInterval(this.data.timer);
    this.setData({
      pauseShow: false,
      continueCancleShow: true,
      okShow: false
    })
  },
  continue: function () {
    this.drawActive();
    this.setData({
      pauseShow: true,
      continueCancleShow: false,
      okShow: false
    })    
  },
  cancle: function (){
    clearInterval(this.data.timer);
    var time_0=new Date().getTime();
    var keeptime_0=time_0-this.data.startime_0;
    this.setData({
      keeptime:keeptime_0,
      pauseShow: true,
      continueCancleShow: false,
      okShow: false,
      clockShow:false      
    });
    let openid=wx.getStorageSync('openid');
    let obj={
      startime:this.data.startime,
      keeptime:this.data.keeptime/(60*1000),
      focustime:1,
      cate:this.data.cateArr[this.data.cateActive].text
    };
    console.log(obj)
    wx.cloud.callFunction({
      name:'addForest',
      data:{
        openid:openid,
        val:obj
      },
      success(res) {
        console.log(res)
        let timer = null;
        wx.hideLoading({
          complete: (res) => {},
        })
        wx.showToast({
          title: '添加成功',
        })
      },
      fail(res) {
        console.log(res)
        wx.hideLoading({
          complete: (res) => {},
        })
        wx.showToast({
          title: '添加失败',
          icon: 'none'
        })
      }
    })

  },
  ok: function () {
    clearInterval(this.data.timer);
    var time_0=new Date().getTime()
    var keeptime_0=time_0-this.data.startime_0
    this.setData({
      keeptime:keeptime_0,
      pauseShow: true,
      continueCancleShow: false,
      okShow: false,
      clockShow: false
    })    
    let openid=wx.getStorageSync('openid');
    let obj={
      startime:this.data.startime,
      keeptime:this.data.keeptime/(60*1000),
      cate:this.data.cateArr[this.data.cateActive].text
    };
    wx.cloud.callFunction({
      name:'addForest',
      data:{
        openid:openid,
        val:obj
      },
      success(res) {
        console.log(res)
        let timer = null;
        wx.hideLoading({
          complete: (res) => {},
        })
        wx.showToast({
          title: '添加成功',
        })
      },
      fail(res) {
        console.log(res)
        wx.hideLoading({
          complete: (res) => {},
        })
        wx.showToast({
          title: '添加失败',
          icon: 'none'
        })
      }
    })
  }
})
