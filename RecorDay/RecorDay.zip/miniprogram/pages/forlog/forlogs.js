//logs.js
const util = require('../../utils/forestime.js')
const util_0=require('../../utils/YMD.js')
Page({
  data: {
    logs: [],
    forestlist:[],
    activeIndex:0,
    dayList:[],
    list: [],     
    sum:[
      {
        title:'今日专注时间(min)',
        val:'0'
      },
      {
        title: '今日专注次数',
        val: '0'
      },
      {
        title: '累计专注时间',
        val: '0分钟'
      },
      {
        title: '累计专注时间',
        val: '0分钟'
      }
    ],
      cateArr: [
      {
        text: '工作'
      },
      {
        text: "学习",
      },
      {
        text: '运动'
      }
    ],
  },

getforest:function(){
  let db = wx.cloud.database();
  let that = this;
  let today=util_0.formatDate();
   var focus_0=0;
   var TotalTime_0=0;
  db.collection('users').where({
    _openid: wx.getStorageSync('openid'),
  })
  .get().then(res=>{
      let arr=JSON.parse(JSON.stringify(res.data[0].forest));
     
      for(var i=0;i<arr.length;i++)
      {
        let arrs=arr[i].startime.slice(0,10);
         console.log(arrs,today)
        if(arrs==today){
          focus_0=arr[i].focustime+focus_0;
          TotalTime_0=TotalTime_0+arr[i].keeptime;
        }
        let keeptime=arr[i].keeptime.toFixed();
        arr[i].keeptime=keeptime;
      }
      TotalTime_0=TotalTime_0.toFixed()
      this.setData({
        forestlist:arr,
        'sum[0].val':TotalTime_0,
        'sum[1].val':focus_0
      })
  })
},

  onShow: function () {
     this.getforest();
  },
  onload:function(){
    util.formatTime()
  }
 
})
